import socket

serverIP = "10.0.1.2"
input_file = "input1.txt"

# dst_ip = str(input("Enter Server IP: "))
dst_ip = serverIP

port = 12346

# reading input file
with open(input_file , 'r') as f:
	lines = f.readlines()


for message in lines:
	cache = socket.socket()
	cache.connect((dst_ip, port))
	
	#Write your code here:
	#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.
	#2. Add the code to parse the response you get from the server.
	
	brk = message.split(' ')
	
	if brk[0].lower() == 'put':
		cache.send('PUT /assignment1/{}/{} HTTP/1.1\r\n\r\n'.format(brk[1].lower() , brk[2][:-1].lower()))
		recvmsg = cache.recv(1024).decode()
		print ('Client received '+ recvmsg)
		print('PUT Operation was successful')
	
	elif brk[0].lower() == 'get':
		cache.send('GET /assignment1/{} HTTP/1.1\r\n\r\n'.format(brk[1][:-1].lower()))
		recvmsg = cache.recv(1024).decode()
		print ('Client received '+ recvmsg)
		if recvmsg[9] == '4':
			print("Key was not found")
			break
		else:
			print("The value for the requested key is {}".format(recvmsg.split('/')[2]))
	
	elif message == '/]':
		cache.send('HTTP/1.1 Connection:Close \r\n\r\n')
		print('Client recieved '+cache.recv(1024).decode())
		print('Connection has been closed successfully.')

	else:
		print("Invalid command given.")	
		break


	cache.close()

