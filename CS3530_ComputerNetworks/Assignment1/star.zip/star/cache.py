import socket

#WRITE CODE HERE:
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).
dict = {}

IP = "10.0.1.2"
server_IP = "10.0.1.3"

# dst_ip = str(input("Enter Server IP: "))
dst_ip = IP

cache = socket.socket()
cache.setsockopt(socket.SOL_SOCKET , socket.SO_REUSEADDR , 1)
print ("Socket successfully created")

dport = 12346
port = 12347
cache.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))
cache.listen(5)
print ("socket is listening")

flag = True

while flag:

	c, addr = cache.accept()
	print ('Got connection from', addr )
	recvmsg = c.recv(1024).decode()
	
	if 'Connection:Close' in recvmsg:	# escape character
		s = socket.socket()
		s.connect((server_IP, port))
		s.send(recvmsg)
		rcv = s.recv(1024).decode() 
		print('Closing Connection')
		c.send(rcv.encode())
		break
	
	print('Cache received '+recvmsg)
	brk = recvmsg.split('/')

	if brk[0][0:3] == 'PUT':
		s = socket.socket()
		s.connect((server_IP, port))
		s.send(recvmsg)
		rcv = s.recv(1024).decode()
		c.send(rcv.encode())
	
	elif brk[0][0:3] == 'GET':
		if brk[2].split(' ')[0] .lower() not in dict.keys():
			s = socket.socket()
			s.connect((server_IP, port))
			s.send(recvmsg)
			rcv = s.recv(1024).decode()
			if rcv[9] == '4':
				print("Key was not found")
				c.send(rcv.encode())
				break
			else:
				val = rcv.split('/')[2]
				dict[brk[2].split(' ')[0] .lower()] = val
				c.send(rcv.encode())
		else:
			c.send("HTTP/1.1 200 OK/{}\r\n\r\n".format(dict[brk[2].split(' ')[0] .lower()] ))

		
c.close()
  #Write your code here
  #1. Uncomment c.send 
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################


  #break