import socket

#WRITE CODE HERE:
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).
dict = {}

IP = "10.0.1.3"
# dst_ip = str(input("Enter Server IP: "))
dst_ip = IP

s = socket.socket()
s.setsockopt(socket.SOL_SOCKET , socket.SO_REUSEADDR , 1)
print ("Socket successfully created")

dport = 12347

s.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))
s.listen(5)
print ("socket is listening")

flag = True

while flag:

	cache, addr = s.accept()
	print ('Got connection from', addr )
	recvmsg = cache.recv(1024).decode()

	
	if 'Connection:Close' in recvmsg:	# escape character
		print('Closing Connection')
		cache.send('HTTP/1.1 200 OK/Connection:Close\r\n\r\n')
		break
	
	print('Server received '+recvmsg)
	brk = recvmsg.split('/')

	if brk[0][0:3] == 'PUT':
		dict[brk[2].lower()]  = brk[3].split(' ')[0].lower()
		cache.send('HTTP/1.1 200 OK \r\n\r\n')
	
	elif brk[0][0:3] == 'GET':
		if brk[2].split(' ')[0] .lower() not in dict.keys():
			flag = False
			cache.send("HTTP/1.1 404 Not Found")
		else:
			cache.send("HTTP/1.1 200 OK/{}\r\n\r\n".format(dict[brk[2].split(' ')[0] .lower()] ))
		
cache.close()
  #Write your code here
  #1. Uncomment c.send 
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################


  #break